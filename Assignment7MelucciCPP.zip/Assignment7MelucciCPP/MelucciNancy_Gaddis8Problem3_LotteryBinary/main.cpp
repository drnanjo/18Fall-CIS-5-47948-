
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 2018
 * Purpose: Binary Search Lottery Winners
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
#define SIZE 10

//function prototype
bool findWinner(int [], int, int);

int main() {
    //initialize array
 
    int playerNum;
    bool result = false;
    int winningNum[10] = {13579, 26791, 26792, 33445, 55555, 62483, 77777, 79422, 85647, 93121};
   //prompt user and validate
    cout<<"Enter your number: "<<endl;
    cin>>playerNum;
    while (playerNum <=0)
    {
        cin.ignore();
        cout<<"Enter a valid number: "<<endl;
        cin>>playerNum;
    }
    
    //call function
    result = findWinner(winningNum, SIZE, playerNum);
   //give results
    if(result){
        cout<<"You have a winning number!"<<endl;
    }
    else
    {
        cout<<"You do not have a winning number."<<endl;
    }
        
   
}//end main
//binary search function
bool findWinner(int winningNum[], int size, int playerNum) 
{
    int start = 0, end = size-1, middle;
    bool foundIt = false;
    //user prompt
    while(start<=end &&!foundIt)
    {
        //classic binary search algorithm - divide and check position
        middle=(start+end)/2;
        
        if(winningNum[middle]==playerNum)
        {
            foundIt = true;
        }
        else if (winningNum[middle]>playerNum){
            end = middle-1;
        } else {
            start=middle+1;
        }
    }
     return foundIt;
}