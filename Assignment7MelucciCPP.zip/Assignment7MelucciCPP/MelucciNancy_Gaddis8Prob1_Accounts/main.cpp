
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 2018
 * Purpose: Look for account number
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototype
void LinearSearch(int[], int);

int main() {
    //initialize array
 
    int nums = 18;
    const int ASIZE = 18;
    int aNumArray[ASIZE] = {5658845, 8080152, 1005231, 4520125, 4562555, 6545321, 7895122, 5552012, 
    3842085, 8777541, 5050552, 7576651, 8451277, 7825877, 7881200,13202859, 1250255, 4581002};
   
    LinearSearch(aNumArray, ASIZE);
    
   
}//end main

void LinearSearch(int array[], int ASIZE) 
{
    //brute force linear search with comparison
    int acctNum;
    bool foundIt = false;
    //user prompt
    cout<<"Please enter the account number: "<<endl;
    cin>>acctNum;
    for(int i = 0; i<ASIZE; i++ )
    {
        if (array[i] == acctNum)
        {
            foundIt = true;
            cout <<"Valid number."<< endl; 
            break;
        }         
        else
        {
         
            
        }
    }
    if (!foundIt)
    cout <<"Invalid number."<< endl; 
     
}