
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 3018
 * Purpose: Learning to use pointers (dynamic array allocation)
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototype
int *dynamicArray(int);

int main() {
    //initialize pointer and int variables
 
    int nums,i;
    int* arrayPtr;
    const int ASIZE = 18;
    //prompt user
    cout<<"How many elements do you want for your array?"<<endl;
    cin>>nums;
    //valid input
    while (nums<= 0){
        cin.ignore();
        cout<<"Please enter a valid array size:"<<endl;
        cin>>nums;    
    }
    //print array
    arrayPtr = dynamicArray(nums);
      cout<<"The elements are: "<<endl;
    for (i=0; i<nums; i++){
        cout<<*(arrayPtr + i)<<" "<<endl;
        
    }
      
      return 0;
}//end of program

//array creation function using pointer
int* dynamicArray(int number)
{
    int *arrayPtr = new int[number];
    //for loop to get user input
    for (int i = 0; i<number; i++)
    {
        cout<<"Enter element number "<<i+1<<":"<<endl;
        cin>>*(arrayPtr + i);
        
    }
    return arrayPtr;
}