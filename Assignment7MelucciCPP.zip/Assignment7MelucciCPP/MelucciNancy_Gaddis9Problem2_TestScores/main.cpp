
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 2018
 * Purpose: Test score array with statistics (using pointer)
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototypes
void sortScores(int[], int);
double avgScores(int[], int);
void printScores(int[], int);

int main() {
    //initialize 

    int size, score, i;
    int *testScores;
    double average;
    cout << "How many test scores do you need to enter?" << endl;
    cin>>size;

    while (size <= 0) {
        cin.ignore();
        cout << "Please enter a valid array size:" << endl;
        cin>>size;
    }

    testScores = new int[size];

    for (i = 0; i < size; i++) {
        cout << "Score " << (i + 1) << ":" << endl;
        cin>>score;
        while (score <= 0) {
            cin.ignore();
            cout << "Please enter a valid score:" << endl;
            cin>>score;
        }
        testScores[i] = score;
    }
        cout << "Here are the unsorted test scores: " << endl;
        printScores(testScores, size);
        cout << "Here are the sorted test scores: " << endl;
        sortScores(testScores, size);
        printScores(testScores, size);

        cout << "Here is the average for the class:" << endl;
        average = avgScores(testScores, size);
        cout << average << endl;
   
}//end main

void sortScores(int *testScores, int size) {
    int *end = testScores + size;

    for (int *start = testScores; start < end - 1; start++) {
        for (int *next = start + 1; next < end; next++) {
            if (*next < *start) {
                int temp = *start;
                *start = *next;
                *next = temp;
            }
        }

    }
}

double avgScores(int *testScores, int size) {
    int sum, i = 0;
    double average;
    int *current = testScores;

    for (i; i < size; i++) {
        sum += *current;
        current++;

    }

    average = (double) sum / size;

    return average;
}

void printScores(int *testScores, int size) {
    int i;
    int *current = testScores;
    for (i = 0; i < size; i++) {

        cout << *current << " " << endl;
        current++;

    }

    cout << endl;
}




//end of program

