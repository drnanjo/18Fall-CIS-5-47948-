
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 2018
 * Purpose: Movie Data with Structs - User input version with budget cost
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototypes and structs

struct MovieData {
    string title;
    string director;
    int releaseYr;
    int runTime;
    float prodCost;
    float revYrOne;

};

void showMData(MovieData movie);

int main() {
    //initialize movie

    MovieData movie1;
    //get valid user input
    cout << "Enter the title of the movie: " << endl;
    getline(cin, movie1.title);
    cout << "Enter the director's name: " << endl;
    getline(cin, movie1.director);
    cout << "Enter the year released: " << endl;
    std::cin >> movie1.releaseYr;
    while (movie1.releaseYr < 1888) {
        cin.ignore();
        cout << "Please enter a valid release year." << endl;
        std::cin >> movie1.releaseYr;
    }
    cout << "Enter the running time in minutes: " << endl;
    std::cin >> movie1.runTime;
    while (movie1.runTime < 1) {
        cin.ignore();
        cout << "Please enter a valid running time." << endl;
        std::cin >> movie1.runTime;
    }
    cout << "Enter the production cost: " << endl;
    std::cin >> movie1.prodCost;
    while (movie1.prodCost < 0) {
        cin.ignore();
        cout << "Please enter a valid production cost." << endl;
        std::cin >> movie1.prodCost;
    }
    cout << "Enter the first year's box office revenue: " << endl;
    std::cin >> movie1.revYrOne;
    while (movie1.revYrOne < 0) {
        cin.ignore();
        cout << "Please enter a valid box office figure." << endl;
        std::cin >> movie1.revYrOne;
    }
    //function call
    showMData(movie1);


    return 0;
}//end main

//movie data function with decision for profit

void showMData(MovieData movie) {
    cout << right;
    cout << "******************************" << endl;
    cout << setw(25) << "Movie Information" << endl;
    cout << "******************************" << endl;
    cout << left;
    cout << setw(23) << "Title: " << movie.title << endl;
    cout << setw(23) << "Director: " << movie.director << endl;
    cout << setw(23) << "Year Released: " << movie.releaseYr << endl;
    cout << setw(23) << "Run Time (minutes): " << movie.runTime << " minutes" << endl;
    cout << "******************************" << endl;

    float movieRev = movie.revYrOne - movie.prodCost;

    if (movieRev > 0) {

        cout << setprecision(2) << fixed << "The movie was profitable. It made $" << movieRev << "." << endl;
    } else if (movieRev < 0) {
        cout << "The movie lost money in its first year." << endl;
    } else {
        cout << "The movie broke even in its first year." << endl;
    }

}
//end of program

