
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 2018
 * Purpose: Structs 
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototypes and structs


struct MovieData
{
    string title;
    string director;
    int releaseYr;
    int runTime;
    
};

void showMData(MovieData movie);


int main() {
    //initialize two movies
    
    MovieData movie1, movie2;
    
    movie1.title = "Arrival";
    movie1.director = "Denis Villeneuve";
    movie1.releaseYr = 2016;
    movie1.runTime = 118;
    
    movie2.title = "Stranger Than Paradise";
    movie2.director = "Jim Jarmusch";
    movie2.releaseYr = 1984;
    movie2.runTime = 89;

    showMData(movie1);
    showMData(movie2);
    
    return 0;
}//end main

//function to show data
void showMData(MovieData movie)
{
    cout <<right;
    cout <<"******************************"<<endl;
    cout <<setw(25) << "Movie Information" <<endl;
    cout <<"******************************"<<endl;
    cout <<left;
    cout <<setw(23) << "Title: "<<movie.title <<endl;
    cout <<setw(23) << "Director: "<<movie.director <<endl;
    cout <<setw(23) << "Year Released: "<<movie.releaseYr <<endl;
    cout <<setw(23) << "Run Time (minutes): "<<movie.runTime << " minutes"<<endl;
    cout <<"******************************"<<endl;
    
}
//end of program

