
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Got Your Number: Sum, Average, Minimum and Maximum
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

int main()
{
  
    const int SIZE = 100; // Array size.
    int numbers[SIZE]; // Array with 100 elements.
    int i = 0; // Loop counter variable.
 
    string filename; // For the user to enter the file name.
    ifstream inputFile; // Input the file stream object.
 
    // Get the file name from the user.
 
    cout << "Enter the filename: "<<endl;
    cin >> filename;
 
    inputFile.open(filename); // Open the file.
    // If the file successfully opened, process it.
 
    if (inputFile)
    {
        while (i < SIZE && inputFile >> numbers[i])
        {
            i++;
        }
 
        // Close the file.
        inputFile.close();
    }
    else
    {
        // Display an error message.
        cout << "Error opening file."<<endl;
    }
 
    // Display the numbers read.
 
    int value = i;
 
    cout << "There are " << value << " numbers in the array."<<endl;
 
    cout << "Here is the list of numbers: "<<endl;
 
    for (int j = 0; j < i; j++)
    {
        cout << numbers[j] << " "<<endl;
 
    }
    cout <<endl;
 
    // Display the sum of the numbers.
 
    cout << "The sum is : "<<endl;
 
    int sum = 0; // Initialize accumulator.
    for (int ctSum = 0; ctSum < SIZE; ctSum++)
    {
        sum += numbers[ctSum];
    }
 
    cout << sum <<endl;
 
    // Display the average of the numbers.
 
    cout << "The average is : "<<endl;
 
    double total = 0; // Initialize accumulator.
    double average; // To hold the average.
 
    for (int ctAverage = 0; ctAverage < SIZE; ctAverage++)
    {
        total += numbers[ctAverage];
    }
 
    average = total / SIZE;
 
    cout << average <<endl;
 
    // Display the highest value of the numbers.
 
    cout << "The maximum value is : "<<endl;
 
    int countMax;
    int max;
 
    max = numbers[0];
    for (countMax = 1; countMax < SIZE; countMax++)
    {
        if (numbers[countMax] > max)
        {
            max = numbers[countMax];
        }
    }
    cout << max <<endl;
 
    // Display the lowest value of the numbers.
 
    cout << "The minimum value is : "<<endl;
 
    int countMin;
    int min;
 
    min = numbers[0];
    for (countMin = 1; countMin < SIZE; countMin++)
    {
        if (numbers[countMin] < min)
        {
            min = numbers[countMin];
        }
    }
    cout << min <<endl;
 
    return 0;
    
}