
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Lo Shu Square
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototype
void checkMagicSquare(int array[][3]);

int main() {
    //initialize array
    int numArray[3][3];

    //get user input
    cout << "Enter the elements for your square" << endl;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << "Enter this position:  (" << i << "," << j << "):";
            cin >> numArray[i][j];
        }
    }
    //print square and get results
    cout << "You entered this square: " << endl;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << numArray[i][j] << "\t";
        }
        cout << endl;
    }
    //function call
    checkMagicSquare(numArray);

}
//method for checking square
void checkMagicSquare(int array[][3]) {
    //set check variable
    bool notMagic = false;
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            if (array[i][j] < 1 || array[i][j] > 9)
                notMagic = true;
        }
    }

    if (notMagic) {
        cout << "This is not a magic square." << endl;
    } else {

        //calculation of diagonal sum
        int dSum = array[0][0] + array[1][1] + array[2][2];


        bool isMagic = true;
        //check row sum
        //check row and column sums
        for (int i = 0; i < 3; i++) {
            int rowSum = 0;
            for (int j = 0; j < 3; j++) {
                rowSum = rowSum + array[i][j];
            }
            if (rowSum != dSum) {
                isMagic = false;
                break;
            }
        }

        //check column Sum   
        for (int i = 0; i < 3; i++) {
            int colSum = 0;
            for (int j = 0; j < 3; j++) {
                colSum = colSum + array[j][i];
            }
            if (colSum != dSum) {
                isMagic = false;
                break;
            }
        }
        //test and feedback
        if (isMagic) {
            cout << "It's a Magic Square\n";
        } else {
            cout << "It's not a Magic Square\n";
        }

    }
}//end of program
