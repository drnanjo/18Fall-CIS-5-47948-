
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Everybody's got something to hide, except for me and my monkey
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <cmath>
#include <fstream>
#include <iostream>
#include <locale>



using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions


/* Global Constant Variables: Months, Days */
const int MONTHS = 3;
const int DAYS = 30;

//Function Prototypes
void getMetData(char[][DAYS]);
void getCount(const char rainOrShine[][DAYS]);
int getMostRain(const int[]);
void displayReport(const int[], const int, const int[], const int, 
                   const int[], const int, const int);
//main program
int main()
{
   char rainOrShine[MONTHS][DAYS] = { };

   //function call
   getMetData(rainOrShine);

 
   return 0;
}

//function definitions
void getMetData(char rainOrShine[][DAYS])
{
   //File stream object 
   ifstream metData;

   //Initialize variables
   int months = 0,
       days = 0;

   //Open file
   metData.open("RainOrShine.txt");
   
   if (metData)
   {
      for (months = 0; months < MONTHS; months++)
      {
         for (days = 0; days < DAYS; days++)
         {
            metData >> rainOrShine[months][days];
         }
      }

      //Function call
      getCount(rainOrShine);
   }
   else
   {
      cout << "File not found\n"
           << "\nPress Enter to close this window ...\n"<<endl;
   }

   //file close
   metData.close();
}


void getCount(const char rainOrShine[][DAYS])
{
   // Initialize Array and summary statistic variables
   int freqSun[MONTHS] = { }, 
       freqRain[MONTHS] = { }, 
       freqCloud[MONTHS] = { };

    int totalSun = 0,
        totalRain = 0,
        totalCloud = 0,
        days = 0,
        months = 0,
        monthName = 0;
   

   for (months = 0; months < MONTHS; months++)
   {      
      for (days = 0; days < DAYS; days++)
      {
         rainOrShine[months][days] == 'S' ? freqSun[months] += 1 :
            rainOrShine[months][days];

         rainOrShine[months][days] == 'R' ? freqRain[months] += 1 :
            rainOrShine[months][days];

         rainOrShine[months][days] == 'C' ? freqCloud[months] += 1 :
            rainOrShine[months][days];
      }

      totalSun += freqSun[months];
      totalRain += freqRain[months];
      totalCloud += freqCloud[months];
   }

   /* Call: getMostR, displayReport */
   monthName = getMostRain(freqRain);
               displayReport(freqSun, totalSun, freqRain, totalRain, 
                             freqCloud, totalCloud, monthName);
}



int getMostRain(const int freqRain[])
{
   /* Variables: Month name, Largest amount, Months (loop counter) */
   int monthName = 0,
       largestAmount = 0,
       months = 0;

   for (months = 0; months < MONTHS; months++)
   {
      if (freqRain[months] > largestAmount)
      {
         largestAmount = freqRain[months];
         monthName = months;
      }
   }

   /* Return: monthName */
   return monthName;
}



void displayReport(const int freqSun[], const int totalS, 
                   const int freqRain[], const int totalR, 
                   const int freqCloud[], const int totalC, 
                   const int monthName)
{
   /* Constant: Character name */
   const int CHAR_NAME = 3;

   const string mName[MONTHS] = { "June", "July", "August" };
   char charName[CHAR_NAME] = { 'S', 'R', 'C' };

   /* Variables: Months, Count (loop counters) */
   int months = 0,
       cnt = 0;

   /* Display: The report */
   cout << "\t\tWeather Summary\n"
      << "\t\t-------------------\n\n\n"
      << "Summary for each month:\n";

   for (months = 0; months < MONTHS; months++)
   {
      cout << "\n" << mName[months] << ":\n"
           << "\n-------------------------------------------------\n";

      cout << "Clear/Sunny: " << setw(3) << right 
           << freqSun[months] << "\t";
      for (cnt = 0; cnt < freqSun[months]; cnt++)
      {
         cout << " " << charName[0];
      }
      cout << "\n-------------------------------------------------\n";

      cout << "Rain: " << setw(3) << right 
           << freqRain[months] << "\t";
      for (cnt = 0; cnt < freqRain[months]; cnt++)
      {
         cout << " " << charName[1]; 
      }
      cout << "\n-------------------------------------------------\n";
   
      cout << "Cloudy: " << setw(2) << right 
           << freqCloud[months] << "\t";
      for (cnt = 0; cnt < freqCloud[months]; cnt++)
      {
         cout << " " << charName[2]; 
      }
      cout << "\n-------------------------------------------------\n";
   }

   cout << "\n\n3-MONTH SUMMARY:\n"
        << "\n-------------------------------------------------"
        << "--------------------------------------------\n";

      cout << "Sunny Days: " << setw(3) << right << totalS << "\t";
      for (cnt = 0; cnt < totalS; cnt++)
      {
         cout << " " << charName[0];
      }
      cout << "\n-------------------------------------------------"
         << "--------------------------------------------\n";

      cout << "Rainy Days: " << setw(3) << right << totalR << "\t";
      for (cnt = 0; cnt < totalR; cnt++)
      {
         cout << " " << charName[1];
      }
      cout << "\n-------------------------------------------------"
           << "--------------------------------------------\n";

      cout << "Cloudy Days: " << totalC << "\t";
      for (cnt = 0; cnt < totalC; cnt++)
      {
         cout << " " <<  charName[2];
      }
      cout << "\n-------------------------------------------------"
           << "--------------------------------------------\n\n";
      
      cout << "\nThe most rain occured in :\n\n" << mName[monthName] << "\n"
           << "-------------------------------------------------\n";
      for (months = 0; months < 1; months++)
      {
         cout << "Rainy Days: " << freqRain[monthName] << "\t";
         for (cnt = 0; cnt < freqRain[monthName]; cnt++)
         {
            cout << " " << charName[1];
         }
         cout << "\n-------------------------------------------------\n";
      }
}
