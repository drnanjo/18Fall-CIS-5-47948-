
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Everybody's got something to hide, except for me and my monkey
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <cmath>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions


int main() {
double food[3][5];

cout<<"This program tells the the zookeeper, vet and administrator about the state of monkey nutrition."<<endl;

for(int i=1; i<=3; i++) {
for(int j=1; j<5; j++) {
cout << "Enter how many pounds monkey " << i << " ate on day " << j << " of week: ";
cin >> food[i-1][j-1];
  
while(food[i-1][j-1] < 0) {
cout << "Invalid value. Try again: ";
cin >> food[i-1][j-1];
}
}
}
cout << endl << endl;
  
double totalFood = 0;
int maxFoodMonkeyIndex = 0;
int maxFoodDayIndex = 0;
int minFoodMonkeyIndex = 0;
int minFoodDayIndex = 0;
  
for(int i=1; i<=3; i++) {
for(int j=1; j<5; j++) {
totalFood += food[i-1][j-1];
if(food[i-1][j-1] > food[maxFoodMonkeyIndex][maxFoodDayIndex]) {
maxFoodMonkeyIndex = i-1;
maxFoodDayIndex = j-1;
}
if(food[i-1][j-1] < food[minFoodMonkeyIndex][minFoodDayIndex]) {
minFoodMonkeyIndex = i-1;
minFoodDayIndex = j-1;
}
}
}
  
cout << "The average amount of food eaten per day: " << totalFood/5 << " pounds." << endl;
cout << "The least amount of food eaten by monkey: " << (minFoodMonkeyIndex + 1) << " on " << (minFoodDayIndex + 1) << " day. " << endl;
cout << "The max amount of food eaten by monkey: " << (maxFoodMonkeyIndex + 1) << " on " << (maxFoodDayIndex + 1) << " day. " << endl;
  
return 0;

}

