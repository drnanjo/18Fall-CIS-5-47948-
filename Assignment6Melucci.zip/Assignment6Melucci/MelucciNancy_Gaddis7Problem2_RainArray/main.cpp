
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Sum, Average, Min and Max for 12 months of rainfall 
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions


int main(int argc, char** argv) {
        
        //greet user
        cout<<"This program will take your input for a year of rainfall, and provide some descriptive statistics."<<endl;
        //initialize variables and parallel arrays
	int i = 0;
	string nameMonth[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	double rain[12], avg, year = 0, highest, lowest;
	string highMonth, lowMonth;
        //for loop to take inputs
	for (i = 0; i < 12; i++) // ask user to enter amount of rainfall for each month
	{
		cout << "How many inches of rain does " << nameMonth[i] << " have? \n";
		cin >> rain[i];
		while (rain[i] < 0)
		{
			cout << "Please enter a number greater than 0." << endl;
			cin >> rain[i];
		}
	}
        //find min and max using if/else
	highest = rain[0]; // finds month with the highest amount of rain
	lowest = rain[0]; // finds month with the least amount of rain

	for (i= 1; i < 12; i++)
	{
		if (rain[i] > highest)
		{
			highMonth = nameMonth[i];
			highest = rain[i];
		}
		else if (rain[i] < lowest)
		{
			lowMonth = nameMonth[i];
			lowest = rain[i];
		}
	}

        //results for min/max
	for (i = 0; i < 12; i++)
	{
		year += rain[i];
		cout << nameMonth[i] << "has " << rain[i] << " inches of rainfall.\n";
	}
        //calculate average
        avg = double(year/12);
	//tell user about results
	cout << setprecision(2) << fixed<< "Total Rainfall throughout the year is " << year << " inches" << endl;
	cout << setprecision(2) << fixed<< "The average monthly rainfall is " << avg << " inches" << endl;
	cout << setprecision(2) << fixed<<"The month with the highest amount of rainfall is " << highMonth << " with " << highest << " inches." << endl;
	cout << setprecision(2) << fixed<<"The month with the lowest amount of rainfall is " << lowMonth << " with " << lowest << " inches." << endl;
 

        return 0;
                
}//end program