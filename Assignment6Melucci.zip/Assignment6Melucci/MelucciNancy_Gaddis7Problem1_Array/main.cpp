 /* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Arrays
 */

#include <cstdlib>
#include<array>
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//A program that estimates sea level rise per year

//function prototype(s)

void bubbleSort(double[], int);

int main(int argc, char** argv) 
{
   
double *scores,	//Dynamic allocation
total = 0.0, // Initialize sum
average;	// Initialize average
int numScores,	//Size of array
count;	//Counter 

cout<<"This program prints an array of test scores and sorts them - largest, smallest and average."<<endl;

//Prompt for the number of test scores
cout << "How many test scores would you like to enter? ";
cin >> numScores;

//Set up array with input scores

scores = new double[numScores];

//Get the test scores
cout << "Enter the test scores below.\n";
for (count = 0; count < numScores; count++)
{
cout << "Test Score " << (count + 1) << ": ";
cin >> scores[count];
}

//Calculate sum
for (count = 0; count < numScores; count++)
{
total += scores[count];
}

//Calculate average 
average = total / numScores;

//Display results


bubbleSort(scores, numScores);


  for (int i = numScores - 1; i >= 0; i--) 
    cout << scores[i]<<endl;

  cout<<"The smallest value is "<<scores[0]<<endl;
  cout<<"The largest value is "<<scores[numScores-1]<<endl;
  cout << fixed << showpoint << setprecision(2);
  cout << "Average score is: " << average << endl; 

//Free memory
delete [] scores;
scores = 0;
                
      
      
    return 0;
}//end main


//sort function
 void bubbleSort(double x[], int n) {
    bool exchanges;
    do {
       exchanges = false;  // no exchanges
       for (int i=0; i<n-1; i++) {
          if (x[i] > x[i+1]) {
             double temp = x[i]; x[i] = x[i+1]; x[i+1] = temp;
             exchanges = true;  // after exchange check again
          }
       }
    } while (exchanges);
 }