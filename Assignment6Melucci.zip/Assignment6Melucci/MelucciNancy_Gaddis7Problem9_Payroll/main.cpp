
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Lo Shu Square
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototype


int main() {
    //initialize array of ids
    int idArray[7] = {5658845, 4520125, 7695122, 8777541, 8451277, 1302850, 7580489};
    //initialize variable arrays
    float hrArray[7];
    float payArray[7];
    float wageArray[7];

    //get user input and assign values
    cout << "Enter the hours worked by the employee. Round partial hours to the nearest quarter hour." << endl;
    for (int i = 0; i < 7; i++) {
        
        cout<<"Enter the hours for "<<idArray[i]<<":"<<endl;
            cin >> hrArray[i];
            while (hrArray[i] < 0){
                cin.ignore();
                cout<<"Enter a valid number of hours for "<<idArray[i]<<":"<<endl;
                   cin >> hrArray[i];
            }
        }
    
    cout << "Enter the employee pay rate, rounded to two decimal places." << endl;
        for (int i = 0; i < 7; i++) {
            
            cout<<"Enter the pay rate for "<<idArray[i]<<":"<<endl;
            cin >> payArray[i];
            while (payArray[i] < 15.00){
                cin.ignore();
                cout<<"Enter a valid payrate for "<<idArray[i]<<":"<<endl;
                   cin >> payArray[i];
            }
        }
    
    //calculate the wages and assign to each employee by id
    for (int i = 0; i < 7; i++){
        
        cout<<"Here is the gross pay for employee #"<<idArray[i]<<":"<<endl;
        wageArray[i] = hrArray[i] * payArray[i];
        cout<<setprecision(2)<<fixed<<wageArray[i]<<endl;
    }
    
    
    return 0;
}//end of program
