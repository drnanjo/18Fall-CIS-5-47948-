
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Living Large
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//A program for number comparisons

int main(int argc, char** argv) {
        
        //greet user
        cout<<"This program for comparing a user input value with the members of a user input array."<<endl;
        //initialize variables and variables
	int i = 0;
        int total = 0;
        int mySize;
        int myNum;
	int myArray [mySize];
        //for loop to take inputs
        cout<<"How large would you like your array to be?"<<endl;
        //validate input
        cin>>mySize;
        
		while (mySize < 0)
		{
                    cin.ignore();
		}
        //fill array
        cout<<"Enter the numbers to fill your array."<<endl;
	for (i = 0; i <= mySize - 1; i++) // fill the array
	{
            cin>>myArray[i];
	}
        cout<<"Done filling the array."<<endl;
        cout<<"What would you like your test number to be?"<<endl;
        cin>>myNum;
        
        //compare values
	for (i= 0; i <= mySize; i++)
	{
            if (myArray[i]> myNum)
            total = total + 1;    
	}

    
        
	//tell user about results
        cout<<"There are  "<<total<<" numbers large than "<<myNum<<" in the array."<<endl;
	
        return 0;
                
}//end program