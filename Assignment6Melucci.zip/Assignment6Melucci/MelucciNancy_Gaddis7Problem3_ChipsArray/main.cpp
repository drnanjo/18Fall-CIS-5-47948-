
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: Salsa!
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//A program for inputing sales totals

int main(int argc, char** argv) {
        
        //greet user
        cout<<"This program will present the sales of our varieties of salsa for the given month."<<endl;
        //initialize variables and parallel arrays
	int i = 0;
        string salesMonth = "";
	string nameSalsa[5] = { "Black Bean and Corn", "Habanero Hot", "Mango", "Lime", "Queso"};
	int sales [5], totalJars = 0, highest, lowest;
	string highSale, lowSale;
        //for loop to take inputs
        cout<<"What month's sales do you wish to input today: "<<endl;
        cin>>salesMonth;
	for (i = 0; i < 5; i++) // ask user to enter the sales for each type
	{
		cout << "How many jars of " << nameSalsa[i] << " were sold? \n";
		cin >> sales[i];
		while (sales[i] < 0)
		{
			cout << "Please enter a number greater than 0." << endl;
			cin >> sales[i];
		}
	}
        //find min and max using if/else
	highest = sales[0]; // finds type with the highest sales
	lowest = sales[0]; // finds type with lowest sales

	for (i= 1; i < 5; i++)
	{
		if (sales[i] > highest)
		{
			highSale = nameSalsa[i];
			highest = sales[i];
		}
		else if (sales[i] < lowest)
		{
			lowSale = nameSalsa[i];
			lowest = sales[i];
		}
	}

        //results for min/max
	for (i = 0; i < 5; i++)
	{
		totalJars += sales[i];
		cout << nameSalsa[i] << " sold " << sales[i] << " jars this month.\n";
	}
        
	//tell user about results
        cout<<"Here are the sales statistics for the month of "<<salesMonth<<":"<<endl;
	cout << setprecision(2) << fixed<< "Total jars sold this month is " << totalJars << " jars of all varieties." << endl;
	cout << setprecision(2) << fixed<<"The best selling variety of salsa is " << highSale << " with " << highest << " jars sold." << endl;
	cout << setprecision(2) << fixed<<"The least popular variety of salsa is " << lowSale << " with only " << lowest << " jars sold." << endl;
 

        return 0;
                
}//end program