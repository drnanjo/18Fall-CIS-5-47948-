
/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: November 2018
 * Purpose: driver test
 */

//System Libraries Here

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//function prototype


int main() {
    //initialize array
    char ansArray[20] = {'A', 'D', 'B', 'B', 'C', 'B', 'A', 'B', 'C', 'D', 'A', 'C', 'D', 'B', 'D', 'C', 'C', 'A', 'D', 'B' };
    char respArray[20];
    int count = 0;

    //get user input
    cout << "Enter your answer for each question." << endl;
    for (int i = 0; i < 20; i++) {     
        //compare and validate
            cout << "Question:" << i + 1 <<":";
            cin >> respArray[i];   
            while ((respArray[i] != 'a') && (respArray[i] != 'b') && (respArray[i] != 'c') && (respArray[i] != 'd') && 
                    (respArray[i] != 'A') && (respArray[i] != 'B') && (respArray[i] != 'C') && (respArray[i] != 'D')) {
                cin.ignore();
                cout << "Please enter a valid answer to question:" << i + 1 <<":";
                cin >> respArray[i];   
            }
            if (toupper(ansArray[i]) == (toupper(respArray[i]))){
                count++;
            } else {
            
            }
    }//feedback
    float score = float(count/20.0) * 100.0;
    cout<<"You got "<<count<<" out of 20 correct for a score of  "<<setprecision(2)<<fixed<<score<<"."<<endl;
            if (count < 15){
                cout<<"You have failed your driver's test. Go home and study. Return in 2 weeks to retake."<<endl;
            } else {
                cout<<"See the clerk at Station 17 for your photo and temp license. Your number is 201B."<<endl;
                cout<< "Your wait time is approximately 105 minutes. Thank you for visiting the California DMV."<<endl;
            }

}//end of program
