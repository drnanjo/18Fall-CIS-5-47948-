/* 
 * File:   main.cpp
 * Author: Melucci
 * Created: December 2018
 * Purpose:  War Game
 */


//System Libraries Here
#include <iostream>
#include <string>
#include <cstdlib> 
#include <cstdio>
//namespace
using namespace std;


//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

string drawCard();
int scoreCard(string);
bool isDrawn(string);
string getCard();

int main() {
    //useful local variables, including Arrays
    int numberOfCards = 52;
    string suit[] = {"Diamonds", "Hearts", "Spades", "Clubs"};
    string facevalue[] = {"Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"};
    string player1 = "";
    string player2 = "";
    int numberOfCardsDrawn = 0;
    string drawnCards[52];
    string drawnCard = "";
    string drawnCard2 = "";
    int playOne = 0;
    int playTwo = 0;
    float play1Rounds = 0;
    float play2Rounds = 0;

    //prompt for inputs
    cout << "Welcome to War. Who is playing?" << endl;
    cin>>player1;
    cout << " and?"<<endl;
    cin>>player2;
    //start game for loop to draw cards
    for (int i = 0; i < numberOfCards; i++) {
        drawnCard = getCard();
        cout << player1 << " draws the " << drawnCard << endl;
        playOne = scoreCard(drawnCard);
        i++;
        drawnCard2 = getCard();
        cout << player2 << " draws the " << drawnCard2 << endl;
        playTwo = scoreCard(drawnCard2);
        i++;
      
        //feedback on round outcome
        if (playOne > playTwo) {
            play1Rounds += 1;
            cout << player1 << " won the round." << endl;
        } else if (playOne < playTwo) {
            play2Rounds += 1;
            cout << player2 << " won the round." << endl;
        }
        else {
            play1Rounds += .5;
            play2Rounds += .5;
            cout << "Tie round." << endl;


        }
    }

    cout << player1<< " won " << play1Rounds << " games" << endl;
    cout << player2<< " won " << play2Rounds << " games" << endl;

    //final score
    if (play1Rounds > play2Rounds)
        cout <<player1<<" wins." << endl;
    if (play1Rounds < play2Rounds)
        cout <<player2<<" wins." << endl;
    if (play1Rounds == play2Rounds)
        cout << "It\'s a tie." << endl;

    cout << "Goodbye." << endl;

}

//function to draw random card
string drawCard() {
    string card;
    int cardvalue = rand() % 13;
    int cardsuit = rand() % 4;
    string suit[] = {"Diamonds", "Hearts", "Spades", "Clubs"};
    string facevalue[] = {"Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"};
    card += facevalue[cardvalue];
    card += " of ";
    card += suit[cardsuit];
    return card;
}
//function to get score for card using substring equality
int scoreCard(string card) {
    card = drawCard();
    int cardvalue;
    string facevalue[] = {"Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"};
    if (card.substr(0, 3) == "Two")
        return 2;
    if (card.substr(0, 3) == "Thr")
        return 3;
    if (card.substr(0, 3) == "Fou")
        return 4;
    if (card.substr(0, 3) == "Fiv")
        return 5;
    if (card.substr(0, 3) == "Six")
        return 6;
    if (card.substr(0, 3) == "Sev")
        return 7;
    if (card.substr(0, 3) == "Eig")
        return 8;
    if (card.substr(0, 3) == "Nin")
        return 9;
    if (card.substr(0, 3) == "Ten")
        return 10;
    if (card.substr(0, 3) == "Jac")
        return 11;
    if (card.substr(0, 3) == "Que")
        return 12;
    if (card.substr(0, 3) == "Kin")
        return 13;
    if (card.substr(0, 3) == "Ave")
        return 14;

}
//function to track cards that have been drawn
bool isDrawn(string card) {
    string drawnCards[52];
    for (int i = 0; i < 52; i++) {
        if (card.compare(drawnCards[i]) == 0) { 
            return true;
        }
    }
    return false; // card has not been drawn yet
}

//function to draw card calls isDrawn to track what is in deck
string getCard() {
    string card = drawCard();
    int numberOfCardsDrawn = 0;
    string drawnCards[52];
    while (isDrawn(card) == true) {
        card = drawCard(); // draw a new card
    }
    drawnCards[numberOfCardsDrawn] = card;
    numberOfCardsDrawn++;
    return card;
}




